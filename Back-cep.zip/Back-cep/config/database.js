module.exports = {
  dialect: "postgres",
  host: "localhost",
  username: "postgres",
  password: "271296",
  database: "apinode",
  define: {
    timestamps: true,
    underscored: true,
  },  
};

const sequelize = require ('require')
const config = require ('../config/database')

const Endereco = require ('../models/endereco')

const connection = new Sequelize(config)

Endereco.init(connection)
Endereco.associate(connection.models)

module.exports = connection
